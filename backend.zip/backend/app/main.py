from fastapi import FastAPI
from .routers import centros_medicos, especialistas, auth_test

app = FastAPI(title="Pocket Doctor API")

from .routers import centros_medicos, especialistas, auth_test

app.include_router(centros_medicos.router, prefix="/api/v1")
app.include_router(especialistas.router,   prefix="/api/v1")
app.include_router(auth_test.router,       prefix="/api/v1")


@app.get("/")
def root():
    return {"message": "Hello Pocket Doctor!"}
