from pydantic import BaseModel, Field
from typing import Optional

class EspecialistaIn(BaseModel):
    nombre: str = Field(..., min_length=2, max_length=120)
    especialidad: str = Field(..., min_length=2, max_length=120)
    ubicacion: Optional[str] = Field(default=None, max_length=160)
    contacto: Optional[str] = Field(default=None, max_length=100)
    disponibilidad: Optional[str] = Field(default=None)  # libre por ahora
    centro_medico_id: Optional[int] = Field(default=None, ge=1)

class EspecialistaOut(EspecialistaIn):
    id: int
