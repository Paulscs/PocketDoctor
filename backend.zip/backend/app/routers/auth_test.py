from fastapi import APIRouter, Depends
from ..core.auth import verify_jwt

router = APIRouter(prefix="/auth-test", tags=["auth"])

@router.get("/me")
def get_current_user(user_id: str = Depends(verify_jwt)):
    """
    Devuelve el ID del usuario autenticado (de Supabase Auth)
    """
    return {"user_id": user_id}
