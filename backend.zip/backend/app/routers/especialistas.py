from fastapi import APIRouter, HTTPException, Path
from typing import List, Dict, Any
from ..core.supabase_client import supabase
from ..schemas.especialistas import EspecialistaIn, EspecialistaOut

router = APIRouter(prefix="/especialistas", tags=["especialistas"])

TABLE = "especialistas"
CENTROS_TABLE = "centros_medicos"

def _centro_existe(centro_id: int) -> bool:
    resp = supabase.table(CENTROS_TABLE).select("id").eq("id", centro_id).execute()
    return bool(resp.data)

@router.get("", response_model=List[EspecialistaOut])
def list_especialistas():
    try:
        resp = supabase.table(TABLE).select("*").order("id", desc=False).execute()
        return resp.data or []
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al listar: {e}")

@router.get("/{id}", response_model=EspecialistaOut)
def get_especialista(id: int = Path(..., gt=0)):
    try:
        resp = supabase.table(TABLE).select("*").eq("id", id).execute()
        rows = resp.data or []
        if not rows:
            raise HTTPException(status_code=404, detail="No encontrado")
        return rows[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al obtener: {e}")

@router.post("", response_model=EspecialistaOut, status_code=201)
def create_especialista(payload: EspecialistaIn):
    try:
        if payload.centro_medico_id is not None and not _centro_existe(payload.centro_medico_id):
            raise HTTPException(status_code=400, detail="centro_medico_id no existe")
        resp = supabase.table(TABLE).insert(payload.dict()).execute()
        if not resp.data:
            raise HTTPException(status_code=500, detail="No se pudo crear")
        return resp.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al crear: {e}")

@router.put("/{id}", response_model=EspecialistaOut)
def update_especialista(id: int = Path(..., gt=0), payload: EspecialistaIn = ...):
    try:
        if payload.centro_medico_id is not None and not _centro_existe(payload.centro_medico_id):
            raise HTTPException(status_code=400, detail="centro_medico_id no existe")
        resp = supabase.table(TABLE).update(payload.dict()).eq("id", id).execute()
        rows = resp.data or []
        if not rows:
            raise HTTPException(status_code=404, detail="No encontrado")
        return rows[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al actualizar: {e}")

@router.delete("/{id}", response_model=Dict[str, Any])
def delete_especialista(id: int = Path(..., gt=0)):
    try:
        resp = supabase.table(TABLE).delete().eq("id", id).execute()
        rows = resp.data or []
        if not rows:
            raise HTTPException(status_code=404, detail="No encontrado")
        return {"deleted": True, "id": id}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al eliminar: {e}")
