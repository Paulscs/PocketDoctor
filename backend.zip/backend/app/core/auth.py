import os
from fastapi import HTTPException, Header
from jose import jwt, JWTError

JWT_SECRET = os.getenv("SUPABASE_JWT_SECRET")
JWT_ALGORITHM = "HS256"

def verify_jwt(authorization: str = Header(...)):
    """
    Extrae y valida el JWT enviado por Supabase Auth.
    Devuelve el 'sub' (user id) si es válido.
    """
    try:
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise ValueError("Formato de token inválido")
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload.get("sub")  # id del usuario en Supabase Auth
    except (ValueError, JWTError):
        raise HTTPException(status_code=401, detail="Token inválido o ausente")
